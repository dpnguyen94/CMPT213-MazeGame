package ca.cmpt213.as4.model;

public class GameCode {
    public static final int INVALID_MOVE_THROUGH_WALLS = 0;
    public static final int VALID_MOVE = 1;
    public static final int GAME_LOST = -1;
    public static final int GAME_WON = 2;
}
