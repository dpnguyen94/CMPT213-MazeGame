These files should be placed into the /public folder of your project
(i.e., in the root of your project, create a public folder).

Ensure that your Spring Boot controllers are not looking for anything in the root folder,
otherwise when browsing to http://localhost:8080/ you'll get an error.
